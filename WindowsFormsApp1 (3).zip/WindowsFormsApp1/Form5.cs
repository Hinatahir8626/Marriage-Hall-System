﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApp1
{
    public partial class Form5 : Form
    {
        OleDbConnection conn;
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        OleDbDataReader reader;
        DataTable dt;
        public Form5()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
         this.Close();
            this.Hide();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            GetBooking();

        }


        void GetBooking()
        {
         conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb");
        dt = new DataTable();
        adapter = new OleDbDataAdapter("SELECT *FROM Booking", conn);
        conn.Open();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String query = "DELETE FROM Booking WHERE Calculate=@calculate";
            cmd = new OleDbCommand(query, conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("DELETE SUCCESSFULLY");
            GetBooking();
            conn.Close();
        }
    }
}
